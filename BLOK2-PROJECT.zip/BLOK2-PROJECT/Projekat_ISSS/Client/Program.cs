﻿using Contract;
using Manager;
using System;
using System.Security.Cryptography.X509Certificates;
using System.ServiceModel;
using System.Threading;

namespace Client
{
    public class Program 
    {     
        static void Main(string[] args)
        {
            WCFClient client = new WCFClient();
            HashSHA1 hashSHA1 = new HashSHA1();

            string srvCertCN = "ids";
            string signCertCN = "client_sign";

            string ipAddress = "10.1.212.178";

            NetTcpBinding binding = new NetTcpBinding();
            binding.Security.Transport.ClientCredentialType = TcpClientCredentialType.Certificate;

            /// Use CertManager class to obtain the certificate based on the "srvCertCN" representing the expected service identity.
            X509Certificate2 srvCert = CertManager.GetCertificateFromStorage(StoreName.TrustedPeople, StoreLocation.LocalMachine, srvCertCN);
            EndpointAddress address = new EndpointAddress(new Uri($"net.tcp://{ipAddress}:10001/Receiver"),
                                      new X509CertificateEndpointIdentity(srvCert));

            using (WCFClient proxy = new WCFClient(binding, address))
            {
                proxy.TestComm();
                Console.WriteLine("TestCommunication() finished.");
               
                while(true)
                {
                    (new Thread(() =>
                    {                  
                        string message = "Zahtev";

                        X509Certificate2 signCert = CertManager.GetCertificateFromStorage(StoreName.My, StoreLocation.LocalMachine, signCertCN);

                        /// Create a signature using SHA1 hash algorithm
                        byte[] signature = DigitalSignature.Create(message, "SHA1", signCert);

                        Console.WriteLine("SendMessage() using {0} certificate finished.", signCertCN);

                        string newHash = proxy.SendRequest(message, signature);
                        string oldHash = client.LoadHash();
                        bool change = hashSHA1.CompareHash(newHash, oldHash);

                        if(change)
                        {
                            Console.WriteLine("Doslo je do promene u Log fajlu " + DateTime.Now);
                            client.ChangeHash(newHash);
                        }
                        else
                        {
                            Console.WriteLine("Log fajl nije promenjen");
                        }
                    })).Start();
                    Thread.Sleep(30000);
                }
            }
        }
    }
}
