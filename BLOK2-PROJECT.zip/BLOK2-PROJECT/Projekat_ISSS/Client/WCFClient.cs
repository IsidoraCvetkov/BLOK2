﻿using Contract;
using System;
using System.ServiceModel;
using System.Security.Cryptography.X509Certificates;
using Manager;
using System.IO;

namespace Client
{
    public class WCFClient : ChannelFactory<IWCFContractClient>, IWCFContractClient
    {
        IWCFContractClient factory;
        public string pathHash = AppDomain.CurrentDomain.BaseDirectory + "HashBase.txt";

        public WCFClient() { }
        public WCFClient(NetTcpBinding binding, EndpointAddress address) : base(binding, address)
        {
            /// cltCertCN.SubjectName should be set to the client's username. .NET WindowsIdentity class provides information about Windows user running the given process
            string cltCertCN = "client";

            this.Credentials.ServiceCertificate.Authentication.RevocationMode = X509RevocationMode.NoCheck;

            /// Set appropriate client's certificate on the channel. Use CertManager class to obtain the certificate based on the "cltCertCN"
            this.Credentials.ClientCertificate.Certificate = CertManager.GetCertificateFromStorage(StoreName.My, StoreLocation.LocalMachine, cltCertCN);

            factory = this.CreateChannel();
        }

        #region LoadHash
        public string LoadHash()
        {
           return File.ReadAllText(pathHash);
        }
        #endregion

        #region ChangeHash
        public void ChangeHash(string newHash)
        {
            File.WriteAllText(pathHash, newHash);    
        }
        #endregion

        #region SendRequest
        public string SendRequest(string message, byte[] sign)
        {
            try
            {
               string newHash = factory.SendRequest(message, sign);
               return newHash;
            }
            catch (Exception e)
            {
                return "[SendMessage] ERROR = " + e.Message;
            }
        }
        #endregion

        #region TestComm
        public void TestComm()
        {
            try
            {
                factory.TestComm();
            }
            catch (Exception e)
            {
                Console.WriteLine("[TestCommunication] ERROR = {0}", e.Message);
            }
        }
        #endregion
    }
}
