﻿using System.Collections.Generic;

namespace Contract
{
    public interface ILoadXML
    {
        Dictionary<string, List<string>> LoadXML();
    }
}
