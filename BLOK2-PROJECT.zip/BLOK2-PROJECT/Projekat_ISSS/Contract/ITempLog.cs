﻿namespace Contract
{
    public interface ITempLog
    {
        void WriteTxt();
        void LoadTxt();
        string CriticalityLevel(string Name);
    }
}
