﻿using System.ServiceModel;

namespace Contract
{
    [ServiceContract]
    public interface IWCFContract
    {
        [OperationContract]
        void TestCommunication();

        [OperationContract]
        void SendMessage(string message, byte[] sign);
    }
}
