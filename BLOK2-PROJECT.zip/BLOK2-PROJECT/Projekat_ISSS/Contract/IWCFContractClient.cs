﻿using System.ServiceModel;

namespace Contract
{
    [ServiceContract]
    public interface IWCFContractClient
    {
        [OperationContract]
        void TestComm();

        [OperationContract]
        string SendRequest(string message, byte[] sign);
    }
}
