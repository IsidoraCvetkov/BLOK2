﻿using System;
using System.Collections.Generic;
using System.ServiceModel;
using System.Threading;
using System.Diagnostics;
using System.Security.Cryptography.X509Certificates;
using Manager;

namespace MST
{
    public class Program
    {
        static void Main(string[] args)
        {
            /// Define the expected service certificate. It is required to establish cmmunication using certificates.
			string srvCertCN = "ids";

            /// Define the expected certificate for signing ("<username>_sign" is the expected subject name).
            /// .NET WindowsIdentity class provides information about Windows user running the given process
            string signCertCN = "mst_sign";

            string ipAddress = "10.1.212.161";

            /// Define subjectName for certificate used for signing which is not as expected by the service
            //string wrongCertCN = "wrong_sign";

            NetTcpBinding binding = new NetTcpBinding();
            binding.Security.Transport.ClientCredentialType = TcpClientCredentialType.Certificate;

            /// Use CertManager class to obtain the certificate based on the "srvCertCN" representing the expected service identity.
            X509Certificate2 srvCert = CertManager.GetCertificateFromStorage(StoreName.TrustedPeople, StoreLocation.LocalMachine, srvCertCN);
            EndpointAddress address = new EndpointAddress(new Uri($"net.tcp://{ipAddress}:9999/Receiver"),
                                      new X509CertificateEndpointIdentity(srvCert));

            Work work = new Work();
            bool check = true;

            using (Work proxy = new Work(binding, address))
            {                
                proxy.TestCommunication();
                Console.WriteLine("TestCommunication() finished.");

                Dictionary<string, List<string>> dict = new Dictionary<string, List<string>>();
                dict = work.LoadXML();
                
                work.LoadTxt();
                while (true)
                {                   
                    (new Thread(() =>
                    {                       
                        Process[] processlist = Process.GetProcesses();
                        foreach (Process theprocess in processlist)
                        {
                            check = work.CheckProcess(theprocess, dict);
                            
                            if (!check)
                            { 
                                string criticality = work.CriticalityLevel(theprocess.ProcessName);

                                string message = DateTime.Now + " " + criticality + " PROCCESS NAME: " + theprocess.ProcessName ;

                                X509Certificate2 signCert = CertManager.GetCertificateFromStorage(StoreName.My, StoreLocation.LocalMachine, signCertCN);

                                /// Create a signature using SHA1 hash algorithm
                                byte[] signature = DigitalSignature.Create(message, "SHA1", signCert);
                                proxy.SendMessage(message, signature);
                   
                                Console.WriteLine("SendMessage() using {0} certificate finished.", signCertCN);
                                work.WriteTxt();
                            }
                        }                       
                    })).Start();        
                    Thread.Sleep(30000);                 
                }
            }           
        }
    }
}
