﻿using Contract;
using Manager;
using System;
using System.Collections.Generic;
using System.Security.Cryptography.X509Certificates;
using System.ServiceModel;
using System.Threading;

namespace Client
{
    public class Program : ITempLog
    {
        public string pathLogFile = "..\\..\\..\\HashBase.txt";



        static void Main(string[] args)
        {
            string srvCertCN = "idsservice";
            string signCertCN = "client_sign";

            NetTcpBinding binding = new NetTcpBinding();
            binding.Security.Transport.ClientCredentialType = TcpClientCredentialType.Certificate;

            /// Use CertManager class to obtain the certificate based on the "srvCertCN" representing the expected service identity.
            X509Certificate2 srvCert = CertManager.GetCertificateFromStorage(StoreName.My, StoreLocation.LocalMachine, srvCertCN);
            EndpointAddress address = new EndpointAddress(new Uri("net.tcp://localhost:10001/Receiver"),
                                      new X509CertificateEndpointIdentity(srvCert));

            using (WCFClient proxy = new WCFClient(binding, address))
            {
                proxy.TestComm();
                Console.WriteLine("TestCommunication() finished. Press <enter> to continue ...");
                Console.ReadLine();

                (new Thread(() =>
                {
                    string message = "Zahtjev";

                    X509Certificate2 signCert = CertManager.GetCertificateFromStorage(StoreName.My, StoreLocation.LocalMachine, signCertCN);

                    /// Create a signature using SHA1 hash algorithm
                    byte[] signature = DigitalSignature.Create(message, "SHA1", signCert);
                    proxy.SendRequest(message, signature);

                    Console.WriteLine("SendMessage() using {0} certificate finished. Press <enter> to continue ...", signCertCN);
                    Console.ReadLine();

                })).Start();
                Thread.Sleep(30000);
            }
            Console.ReadLine();
        }

        public void LoadTxt()
        {
            throw new NotImplementedException();
        }

        public void WriteTxt()
        {
            throw new NotImplementedException();
        }
    }
}
