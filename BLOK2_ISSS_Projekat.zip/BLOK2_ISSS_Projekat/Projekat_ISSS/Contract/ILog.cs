﻿
namespace Contract
{
    public interface ILog
    {
        void LogFile(string message);
    }
}
