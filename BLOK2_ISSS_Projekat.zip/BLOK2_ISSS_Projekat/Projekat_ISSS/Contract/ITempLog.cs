﻿
namespace Contract
{
    public interface ITempLog
    {
        void WriteTxt();
        void LoadTxt();
    }
}
