﻿using System.Collections.Generic;
using System.Diagnostics;

namespace Contract
{
    public interface IWork
    {
        Dictionary<string, List<string>> LoadXML();
        bool CheckProcess(Process process, Dictionary<string, List<string>> dict);
    }
}
