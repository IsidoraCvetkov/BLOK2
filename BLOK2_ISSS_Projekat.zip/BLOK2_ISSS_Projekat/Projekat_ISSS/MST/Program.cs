﻿using System;
using System.Collections.Generic;
using System.ServiceModel;
using System.Threading;
using System.Diagnostics;
using System.Security.Cryptography.X509Certificates;
using Manager;

namespace MST
{
    public class Program
    {
        static void Main(string[] args)
        {
            /// Define the expected service certificate. It is required to establish cmmunication using certificates.
			string srvCertCN = "idsservice";

            /// Define the expected certificate for signing ("<username>_sign" is the expected subject name).
            /// .NET WindowsIdentity class provides information about Windows user running the given process
            string signCertCN = "mst_sign";

            /// Define subjectName for certificate used for signing which is not as expected by the service
            string wrongCertCN = "wrong_sign";

            NetTcpBinding binding = new NetTcpBinding();
            binding.Security.Transport.ClientCredentialType = TcpClientCredentialType.Certificate;

            /// Use CertManager class to obtain the certificate based on the "srvCertCN" representing the expected service identity.
            X509Certificate2 srvCert = CertManager.GetCertificateFromStorage(StoreName.My, StoreLocation.LocalMachine, srvCertCN);
            EndpointAddress address = new EndpointAddress(new Uri("net.tcp://localhost:9999/Receiver"),
                                      new X509CertificateEndpointIdentity(srvCert));
            bool check = true;

            using (Work proxy = new Work(binding, address))
            {
                proxy.TestCommunication();
                Console.WriteLine("TestCommunication() finished. Press <enter> to continue ...");
                Console.ReadLine();

                (new Thread(() =>
                {
                    Dictionary<string, List<string>> dict = new Dictionary<string, List<string>>();
                    dict = proxy.LoadXML();
                    Process[] processlist = Process.GetProcesses();
                    foreach (Process theprocess in processlist)
                    {
                        check = proxy.CheckProcess(theprocess, dict);
                        if(!check)
                        {
                            string message = theprocess.ProcessName;

                            X509Certificate2 signCert = CertManager.GetCertificateFromStorage(StoreName.My, StoreLocation.LocalMachine, signCertCN);

                            /// Create a signature using SHA1 hash algorithm
                            byte[] signature = DigitalSignature.Create(message, "SHA1", signCert);
                            proxy.SendMessage(message, signature);

                            Console.WriteLine("SendMessage() using {0} certificate finished. Press <enter> to continue ...", signCertCN);
                            Console.ReadLine();
                        }
                    }
                })).Start();
                Thread.Sleep(30000);
            }
            Console.ReadLine();
        }
    }
}
