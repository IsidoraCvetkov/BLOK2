﻿using Contract;
using Manager;
using System;
using System.Security.Cryptography.X509Certificates;
using System.ServiceModel;

namespace IDS
{
    public class Program
    {
        static void Main(string[] args)
        {
            string srvCertCN = "idsservice";
            IDSService service = new IDSService();

            NetTcpBinding binding = new NetTcpBinding();
            binding.Security.Transport.ClientCredentialType = TcpClientCredentialType.Certificate;

            string address = "net.tcp://localhost:9999/Receiver";
            ServiceHost host = new ServiceHost(typeof(IDSService));
            host.AddServiceEndpoint(typeof(IWCFContract), binding, address);

            string address1 = "net.tcp://localhost:10001/Receiver";
            ServiceHost host1 = new ServiceHost(typeof(IDSService));
            host1.AddServiceEndpoint(typeof(IWCFContractClient), binding, address1);

            ///If CA doesn't have a CRL associated, WCF blocks every client because it cannot be validated
            host.Credentials.ClientCertificate.Authentication.RevocationMode = X509RevocationMode.NoCheck;
            host1.Credentials.ClientCertificate.Authentication.RevocationMode = X509RevocationMode.NoCheck;

            ///Set appropriate service's certificate on the host. Use CertManager class to obtain the certificate based on the "srvCertCN"
            host.Credentials.ServiceCertificate.Certificate = CertManager.GetCertificateFromStorage(StoreName.My, StoreLocation.LocalMachine, srvCertCN);
            host1.Credentials.ServiceCertificate.Certificate = CertManager.GetCertificateFromStorage(StoreName.My, StoreLocation.LocalMachine, srvCertCN);
            //host1.Credentials.ServiceCertificate.Certificate = CertManager.GetCertificateFromFile("IDSSerivce.pfx");

            try
            {
                host.Open();
                host1.Open();
                Console.WriteLine("WCFService is started.\n");
                Console.ReadKey();

            }
            catch (Exception e)
            {
                Console.WriteLine("[ERROR] {0}", e.Message);
                Console.WriteLine("[StackTrace] {0}", e.StackTrace);
            }
            finally
            { 
                host.Close();
                host1.Close();
            }
        }
    }
}
