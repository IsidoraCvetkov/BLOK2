﻿using Contract;
using System;
using System.Collections.Generic;
using System.Xml;
using System.Diagnostics;
using System.Management;
using System.ServiceModel;
using Manager;
using System.Security.Cryptography.X509Certificates;
using System.Linq;
using System.IO;

namespace MST
{
    public class Work :  ChannelFactory<IWCFContract>, IWCFContract, IWork, ILoadXML, ITempLog
    {
        IWCFContract factory;
        string whiteListPath = AppDomain.CurrentDomain.BaseDirectory + "whitelist.xml";
        public string pathTxt = AppDomain.CurrentDomain.BaseDirectory + "tempLogTxtFile.txt";

        public Dictionary<string, int> processesLog = new Dictionary<string, int>();

        public Work()
        {
        }

        public Work(NetTcpBinding binding, EndpointAddress address) : base(binding, address)
        {
            /// cltCertCN.SubjectName should be set to the client's username. .NET WindowsIdentity class provides information about Windows user running the given process
            string cltCertCN = "mst";
         
            this.Credentials.ServiceCertificate.Authentication.RevocationMode = X509RevocationMode.NoCheck;

            /// Set appropriate client's certificate on the channel. Use CertManager class to obtain the certificate based on the "cltCertCN"
            this.Credentials.ClientCertificate.Certificate = CertManager.GetCertificateFromStorage(StoreName.My, StoreLocation.LocalMachine, cltCertCN);

            factory = this.CreateChannel();
        }

        #region CheckProcess
        public bool CheckProcess(Process process, Dictionary<string, List<string>> dict)
        {
            bool check = true;
            string user;
            List<string> temp = new List<string>();

            if (dict.ContainsKey(process.ProcessName))
            {
                temp = dict[process.ProcessName];
                user = GetProcessOwner(process.Id);
                if (!temp.Contains(user))
                    check = false;
            }
            return check;
        }
        #endregion

        #region GetProcessOwner
        public string GetProcessOwner(int processId)
        {
            string query = "Select * From Win32_Process Where ProcessID = " + processId;
            ManagementObjectSearcher searcher = new ManagementObjectSearcher(query);
            ManagementObjectCollection processList = searcher.Get();

            foreach (ManagementObject obj in processList)
            {
                string[] argList = new string[] { string.Empty, string.Empty };
                int returnVal = Convert.ToInt32(obj.InvokeMethod("GetOwner", argList));
                if (returnVal == 0)
                {
                    return  argList[0];   // return DOMAIN\user
                }
            }
            return "NO OWNER";
        }
        #endregion

        #region LoadXML
        public Dictionary<string, List<string>> LoadXML()
        {
            Dictionary<string, List<string>> whitelistDictionary = new Dictionary<string, List<string>>();
            List<string> processes = new List<string>();
            string process;
            string temp;
            string[] role;

            using (XmlReader reader = XmlReader.Create(whiteListPath))
            {
                while (reader.Read())
                {
                    if (reader.IsStartElement())
                    {
                        if (reader.Name.ToString() == "process")
                        {
                            process = reader.ReadString();

                            if (reader.Name.ToString() == "role")
                            {                           
                                temp = reader.ReadString();
                                role = temp.Split(',');

                                foreach (string s in role)
                                {
                                    processes.Add(s);
                                }
                                whitelistDictionary.Add(process, processes);
                            }
                        }
                    }
                }
            }
            Console.WriteLine("Ucitao sam XML");

            return whitelistDictionary;
        }
        #endregion

        #region SendMessage
        public void SendMessage(string message, byte[] sign)
        {
            try
            {
                factory.SendMessage(message, sign);
            }
            catch (Exception e)
            {
                Console.WriteLine("[SendMessage] ERROR = {0}", e.Message);
            }
        }
        #endregion

        #region TestCommunication
        public void TestCommunication()
        {
            try
            {
                factory.TestCommunication();
            }
            catch (Exception e)
            {
                Console.WriteLine("[TestCommunication] ERROR = {0}", e.Message);
            }
        }

        #endregion

        #region WriteTxt
        public void WriteTxt()
        {
            if(!File.Exists(pathTxt))
            {
                FileStream file = File.Create(pathTxt);
            }

            List<string> lines = new List<string>();
                
           foreach (KeyValuePair<string, int> kvp in processesLog)
           {
              string line = kvp.Key + " " + kvp.Value.ToString();
                lines.Add(line);
           }

            File.WriteAllLines(pathTxt, lines);
            
        }
        #endregion

        #region LoadTxt
        public void LoadTxt()
        {
            
            string name;
            int value;

            if(File.Exists(pathTxt))
            {
                if (new FileInfo("tempLogTxtFile.txt").Length != 0)
                {
                    string[] lines = File.ReadAllLines(pathTxt);

                    foreach (string line in lines)
                    {
                        string[] temp = line.Split(' ');
                        name = temp[0];
                        value = Int32.Parse(temp[1]);
                        processesLog.Add(name, value);
                    }
                    
                }
                else
                {
                    Console.WriteLine("U tempLogTxt nema podataka");
                }
            }
            else
            {
                Console.WriteLine("TempLogTxt ne postoji");
            }
           


        }

        #endregion

        #region CriticalityLevel
        public string CriticalityLevel(string Name)
        {
           string critcalityLevel = "";

           if(processesLog.ContainsKey(Name))
           {
                int value=processesLog[Name];
                value++;

                if(value == 2)
                {
                    critcalityLevel = "WARNING";
                    processesLog[Name] = value;
                }
                else if(value>=3)
                {
                    critcalityLevel = "CRITICAL";
                    processesLog[Name] = value;
                }
           }
           else
           {
                processesLog.Add(Name, 1);
                critcalityLevel = "INFORMATION";
           }

            return critcalityLevel;
        }
        #endregion
    }
}
