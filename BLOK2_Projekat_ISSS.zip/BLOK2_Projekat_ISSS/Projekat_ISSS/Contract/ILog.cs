﻿
namespace Contract
{
    public interface ILog
    {
        void WriteTxt();
        void LoadTxt();
        void LogFile();
    }
}
