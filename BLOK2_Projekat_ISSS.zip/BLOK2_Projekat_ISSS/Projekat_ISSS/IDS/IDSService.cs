﻿using Contract;
using Manager;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;

[assembly: log4net.Config.XmlConfigurator(Watch = true)]

namespace IDS
{
    class IDSService : IWCFContract, ILog
    {
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public string pathTxt = "..\\..\\..\\tempLogTxtFile.txt";
        public string pathLogFile = "..\\..\\..\\IDSLogFile.txt";

        public Dictionary<string, int> processesLog = new Dictionary<string, int>();
        
        #region SendMessage
        public void SendMessage(string message, byte[] sign)
        {
            X509Certificate2 clientCertificate = CertManager.GetCertificateFromStorage(StoreName.My, StoreLocation.LocalMachine, "mst_sign");

            /// Verify signature using SHA1 hash algorithm
            if (DigitalSignature.Verify(message, "SHA1", sign, clientCertificate))
            {
                Console.WriteLine("Digital Signature is valid.");
            }
            else
            {
                Console.WriteLine("Digital Signature is invalid.");
            }
        }
        #endregion

        #region TestCommunication
        public void TestCommunication()
        {
            Console.WriteLine("Communication established.");
        }
        #endregion

        #region CheckMessage
        public void CheckMessage(string message)
        {
            if (processesLog.ContainsKey(message))
            {
                int value = processesLog[message];
                value++;

                switch (value)
                {
                    case 1:
                        log.Info("Proccess name: " + message + " Proccess value: " + processesLog[message]);

                        break;
                    case 2:
                        log.Warn("Procces name: " + message + " Proccess value: " + processesLog[message]);
                        break;
                    case 3:
                        //log.Fatal("Procces name: " + message + " Proccess value: " + processesLog[message]);
                        break;
                    default:
                        if (value > 3)
                        {
                            //log.Fatal("Procces name: " + message + " Proccess value: " + processesLog[message]);
                        }
                        else
                        {
                            break;
                        }
                     break;
                }
            }
        }
        #endregion

        #region LoadTxt

        public void LoadTxt()
        {
            string[] lines = System.IO.File.ReadAllLines(pathTxt);
            string name;
            int value;

            if (lines.Count() != 0)
            {             
                foreach (string line in lines)
                {
                    string[] temp = line.Split(' ');
                    name = temp[0];
                    value = Int32.Parse(temp[1]);
                    processesLog.Add(name, value);
                }
            }
        }
        #endregion

        #region WriteTxt
        public void WriteTxt()
        { 
            using (System.IO.StreamWriter file = new System.IO.StreamWriter(pathTxt))
            {
                System.IO.File.WriteAllText(pathTxt, string.Empty);

                foreach (KeyValuePair<string, int> kvp in processesLog)
                {
                    string line = kvp.Key + " " + kvp.Value.ToString();

                    file.WriteLine(pathTxt, line);
                }
            }
        }
        #endregion

        #region LogFile
        public void LogFile()
        {
        }
        #endregion
    }
}
