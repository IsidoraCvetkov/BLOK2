﻿using Contract;
using Manager;
using System;
using System.IO;
using System.Security.Cryptography.X509Certificates;

namespace IDS
{
    class IDSService : IWCFContract, ILog, IWCFContractClient
    {
        public string pathLogFile = AppDomain.CurrentDomain.BaseDirectory + "LogFile.txt";
   
        #region SendMessage
        public void SendMessage(string message, byte[] sign)
        {
            X509Certificate2 clientCertificate = CertManager.GetCertificateFromStorage(StoreName.My, StoreLocation.LocalMachine, "mst_sign");

            /// Verify signature using SHA1 hash algorithm
            if (DigitalSignature.Verify(message, "SHA1", sign, clientCertificate))
            {
                Console.WriteLine("Digital Signature is valid.");
                LogFile(message);                
            }
            else
            {
                Console.WriteLine("Digital Signature is invalid.");
            }
        }
        #endregion

        #region LogFile
        public void LogFile(string message)
        {

            using (StreamWriter sw = File.AppendText(pathLogFile))
            {
                sw.WriteLine(message);
                
            }
        }

        #endregion

        #region TestComm

        public void TestComm()
        {
            try
            {
                Console.WriteLine("Communication established.");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            
        }

        public string SendRequest(string message, byte[] sign)
        {
            X509Certificate2 clientCertificate = CertManager.GetCertificateFromStorage(StoreName.My, StoreLocation.LocalMachine, "client_sign");
            string hash = "";
            /// Verify signature using SHA1 hash algorithm
            if (DigitalSignature.Verify(message, "SHA1", sign, clientCertificate))
            {
                Console.WriteLine("Digital Signature is valid.");
                HashSHA1 newHash = new HashSHA1();
                string text = ReadLog();
                hash = newHash.Hash(text);

                return hash;
            }
            else
            {
                Console.WriteLine("Digital Signature is invalid.");
                return hash;
            }
        }

        #endregion

        #region TestCommunucation
        public void TestCommunication()
        {
            Console.WriteLine("Communication established.");
        }
        #endregion

        #region ReadLog

        public string ReadLog()
        {
            return File.ReadAllText(pathLogFile);

        }
        #endregion
    }
}
