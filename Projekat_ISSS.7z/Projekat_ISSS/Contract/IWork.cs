﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contract
{
    public interface IWork
    {
        Dictionary<string, List<string>> loadXML();

        bool checkProcess(Process process, Dictionary<string, List<string>> dict);
    }
}
