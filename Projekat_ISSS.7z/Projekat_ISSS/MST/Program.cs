﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.Xml.Linq;
using System.Xml;
using System.Timers;
using System.Threading;
using System.Security.Principal;
using System.Diagnostics;

namespace MST
{
    public class Program
    {
        static void Main(string[] args)
        {
            NetTcpBinding binding = new NetTcpBinding();
            string address = "net.tcp://localhost:9756/WCFService";

            Work identity = Thread.CurrentPrincipal as Work;
            bool check = true;

            (new Thread(() => {

                Dictionary<string, List<string>> dict = new Dictionary<string, List<string>>();
                dict = identity.loadXML();
                Process[] processlist = Process.GetProcesses();
                foreach (Process theprocess in processlist)
                {
                    check = identity.checkProcess(theprocess, dict);

                    Console.WriteLine(check);
                }   

            })).Start();


            Console.ReadLine();
        }

        
    }
}
