﻿using Contract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Xml;
using System.Diagnostics;
using System.Management;
using System.ServiceModel;
using Manager;
using System.Security.Cryptography.X509Certificates;

namespace MST
{
    public class Work :  ChannelFactory<IWCFContract>, IWCFContract,IWork
    {

        IWCFContract factory;

        public Work(NetTcpBinding binding, EndpointAddress address)
            : base(binding, address)
        {
            /// cltCertCN.SubjectName should be set to the client's username. .NET WindowsIdentity class provides information about Windows user running the given process
            string cltCertCN = "mst";

          
            this.Credentials.ServiceCertificate.Authentication.RevocationMode = X509RevocationMode.NoCheck;

            /// Set appropriate client's certificate on the channel. Use CertManager class to obtain the certificate based on the "cltCertCN"
            this.Credentials.ClientCertificate.Certificate = CertManager.GetCertificateFromStorage(StoreName.My, StoreLocation.LocalMachine, cltCertCN);

            factory = this.CreateChannel();
        }

        public bool checkProcess(Process process, Dictionary<string, List<string>> dict)
        {
            bool check = false;
            string user;
            List<string> temp = new List<string>();

            if (dict.ContainsKey(process.ProcessName))
            {
                temp = dict[process.ProcessName];
                user = GetProcessOwner(process.Id);

                if (temp.Contains(user))
                    check = true;
            }

            return check;
        }

        public string GetProcessOwner(int processId)
        {
            string query = "Select * From Win32_Process Where ProcessID = " + processId;
            ManagementObjectSearcher searcher = new ManagementObjectSearcher(query);
            ManagementObjectCollection processList = searcher.Get();

            foreach (ManagementObject obj in processList)
            {
                string[] argList = new string[] { string.Empty, string.Empty };
                int returnVal = Convert.ToInt32(obj.InvokeMethod("GetOwner", argList));
                if (returnVal == 0)
                {
                    return argList[1] + "\\" + argList[0];   // return DOMAIN\user
                }
            }
            return "NO OWNER";
        }

        public Dictionary<string, List<string>> loadXML()
        {
            //Dictionary<string, List<string>> dict = new Dictionary<string, List<string>>();
            Dictionary<string, List<string>> dict = new Dictionary<string, List<string>>();
            List<string> processes = new List<string>();
            string process;
            string temp;
            string[] role;

            using (XmlReader reader = XmlReader.Create("C:\\Users\\Administrator\\Desktop\\Projekat_ISSS\\whitelist.xml"))

            {
                while (reader.Read())
                {
                    if (reader.IsStartElement())
                    {
                        if (reader.Name.ToString() == "process")
                        {
                            Console.WriteLine("process is : " + reader.ReadString());
                            process = reader.ReadString();


                            if (reader.Name.ToString() == "role")
                            {
                                Console.WriteLine("group/user is : " + reader.ReadString());
                                temp = reader.ReadString();
                                role = temp.Split(',');

                                foreach (string s in role)
                                    processes.Add(s);

                                dict.Add(process, processes);
                            }
                        }
                    }
                }
            }

            return dict;
        }

        public void SendMessage(string message, byte[] sign)
        {
            try
            {
                factory.SendMessage(message, sign);
            }
            catch (Exception e)
            {
                Console.WriteLine("[SendMessage] ERROR = {0}", e.Message);
            }
        }

        public void TestCommunication()
        {
            try
            {
                factory.TestCommunication();
            }
            catch (Exception e)
            {
                Console.WriteLine("[TestCommunication] ERROR = {0}", e.Message);
            }
        }
    }
}
